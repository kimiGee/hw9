from booklover import Booklover

print("Hi, booklover!")